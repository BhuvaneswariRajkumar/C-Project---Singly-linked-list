# CProject-SinglyLinkedList
This repository includes a Student Record Management System and a Hospital Management System, both developed in C. The Student System allows efficient management of student records using a singly linked list, while the Hospital System streamlines patient record management. 
